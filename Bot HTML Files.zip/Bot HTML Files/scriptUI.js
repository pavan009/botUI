// ******  UI CODE STARTS ********
glob=0;
var time = new Date();

function closeReport(){
 // alert(`Hey Hi`);
  //document.getElementById('report').style.visibility='hidden';

  // var myobj = document.getElementById("report");
  // myobj.remove();

  document.getElementById('report').innerHTML=``;

  document.getElementById('webchat').style.visibility='visible';


}


function direct_line(){
  console.log('in direct line') 
	
   const store = window.WebChat.createStore({}, ({ dispatch }) => next => action => {
            if (action.type === 'DIRECT_LINE/INCOMING_ACTIVITY') {
              const event = new Event('webchatincomingactivity');

              event.data = action.payload.activity;
              window.dispatchEvent(event);
            }
            if (action.type === 'DIRECT_LINE/CONNECT_FULFILLED') {
            // When we receive DIRECT_LINE/CONNECT_FULFILLED action, we will send an event activity using WEB_CHAT/SEND_EVENT
            dispatch({
              type: 'WEB_CHAT/SEND_EVENT',
              payload: {
                name: 'webchat/join',
                value: { language: window.navigator.language }
              }
            });
          }
          return next(action);
        });




         window.addEventListener('webchatincomingactivity', ({ data }) => {
          if(data.type=="typing")
          {
        //     var div_obj = document.getElementById('report-cls');
        //   var button_obj = document.createElement("BUTTON");
        // //   var i_obj = document.createElement("I");
        //     button_obj.setAttribute("id","cls_button")
        // //document.getElementById('cls_button').setAttribute('onclick','myFunction')
        //   var t = document.createTextNode("X");
        //   button_obj.appendChild(t);
        //   div_obj.appendChild(button_obj);
        //   // $('body','#close-btn').click(function(e){
        //   //   $('#webchat').hide();
        //   //   event.stopPropagation();
        //   // })
        
        document.getElementById('report').innerHTML= `
          <div style="background:white;text-align: end;"><button id="cls_button" onclick="closeReport()">X</button></div>
          <iframe width="100%" height="500" src="https://app.powerbi.com/reportEmbed?reportId=060924e1-f8b3-46f2-a512-52e8a67997f8&autoAuth=true&ctid=3c8ea0e4-127c-4a02-ac65-58830e4ac608&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLXNvdXRoLWVhc3QtYXNpYS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldC8ifQ%3D%3D" frameborder="0" allowFullScreen="true"></iframe>`;  
            
        document.getElementById('webchat').style.visibility='hidden';
          
        //   div_obj.appendChild(button_obj);
        //   i_obj.setAttribute("class","material-icons");
        //   i_obj.innerHTML = "close";
        //   button_obj.appendChild(i_obj);
        //   var link = document.createElement('link'); 
  
        // // set the attributes for link element  
        // link.rel = 'stylesheet';  
      
        // link.type = 'text/css'; 
      
        // link.href = 'bot.css';  

        // var link1 = document.createElement('link'); 
  
        // // set the attributes for link element  
        // link1.rel = 'stylesheet'; 
      
        // link1.href = 'https://fonts.googleapis.com/icon?family=Material+Icons'; 
  
        // // Append link element to HTML head 
        // document.appendChild(link1); 
        // var script = document.createElement('script');
        // script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js';
        // document.appendChild(script);
          // // Add span
          // var span_obj = document.createElement("span");

          // // Set attribute for span element, such as id
          // span_obj.setAttribute("id", "span_New");

          // // Set text for span element
          // span_obj.innerHTML = "close";

          // div_obj.appendChild(span_obj);


          }
        console.log(`Received an activity of type "${data.type}":`);
        console.log(data);
        });

	 const styleSet = window.WebChat.createStyleSet({
          //bubbleBackground: '	#D3D3D3',
          bubbleFromUserBackground: '#49a5a2',
          
			botAvatarImage: 'bot-icon.svg'  ,
			//bubbleBackground: 'rgb(237, 237, 250)',
			userAvatarImage: 'userAvatar.jpg',
          //  bubbleBorderColor: 'rgb(237, 237, 250)',
            bubbleBorderRadius: 10,
            bubbleBorderStyle: 'solid',
    
            bubbleNubOffset: 'bottom',
            bubbleNubSize: 0,
            bubbleFromUserTextColor: 'White',

           bubbleFromUserBackground: '#696969',
            bubbleFromUserNubOffset: 'bottom',
           bubbleFromUserBorderColor: '#E6EFBC',
            bubbleFromUserNubSize: 0,
            bubbleFromUserBorderRadius: 10,
            bubbleFromUserBorderStyle: 'solid',

           //backgroundColor: 'rgba(255,255,255,0.8)',

            suggestedActionBackground: '#00BFFF',
            suggestedActionBorder: undefined, // split into 3, null
            suggestedActionBorderColor: undefined, // defaults to accent
            suggestedActionBorderStyle: 'solid',
            suggestedActionBorderWidth: 0,
            suggestedActionBorderRadius: 40,
           // suggestedActionImageHeight: 20,


            suggestedActionTextColor: 'white',
            suggestedActionDisabledBackground: undefined, // defaults to suggestedActionBackground
            suggestedActionDisabledBorder: null,
            suggestedActionDisabledBorderColor: '#FFFFFF',
            suggestedActionDisabledBorderStyle: 'solid',
            suggestedActionDisabledBorderWidth: 0,
            suggestedActionDisabledTextColor: undefined, // defaults to subtle
           // suggestedActionHeight: 40,
            suggestedActionLayout: 'carousel', // either "carousel" or "stacked"
 



           transcriptOverlayButtonBackground: 'Black',
           transcriptOverlayButtonBackgroundOnFocus: 'Green',
           transcriptOverlayButtonBackgroundOnHover: 'Green',
           transcriptOverlayButtonColor: 'Grey',
           transcriptOverlayButtonColorOnFocus: undefined, // defaults to transcriptOverlayButtonColor
           transcriptOverlayButtonColorOnHover: undefined,
		

			 userAvatarInitials: 'WC',
			 botAvatarInitials: 'BF'
           
			
			

         });
         
          styleSet.textContent = {
            ...styleSet.textContent,
            fontFamily: "'Cairo'",
            //fontWeight: 600,
            fontSizeSmall: '16%',
         };
		 
		 /*const styleOptions = {
            bubbleBackground: 'Black',
            bubbleFromUserBackground: 'Black'
         };*/
  (async function () {  
				let authorizationToken;
		let region;
		const speechServicesTokenRes = await fetch(
		  'https://centralus.api.cognitive.microsoft.com/sts/v1.0/issuetoken',
		  { method: 'POST', headers: { 'Ocp-Apim-Subscription-Key': 'e523e09bbe4a42aea8337ec5ecb9d862' } }
		);

		if (speechServicesTokenRes.status === 200) {
		  region = 'centralUS',
		  authorizationToken = await speechServicesTokenRes.text()
		} else {
		  return (new Error('error!'))
		}

		const webSpeechPonyfillFactory = await window.WebChat.createCognitiveServicesSpeechServicesPonyfillFactory( {
		  authorizationToken: authorizationToken,
		  region: region
    } );
    //GOSbFDLaCO8.eR15CQHgI0MeveqFMX9NkjwUFAojMcE1VpobJpJqNP4
  window.WebChat.renderWebChat({
    directLine: window.WebChat.createDirectLine({ secret: '7Flta2hvBOw.1gXE0QuGhfm2pq_LhLU8wvppak4NDrkSVHksi4HBMgU',
     }), 
    // webSpeechPonyfillFactory: window.WebChat.createBrowserWebSpeechPonyfillFactory(),
      //webSpeechPonyfillFactory: webSpeechPonyfillFactory,
    styleSet,
	  store
     
  
    // Passing avatar initials when rendering Web Chat

  }, document.getElementById('webchat'));

  // We will hook into "webchatincomingactivity" event
  document.querySelector('#webchat > *').focus();
 })().catch(err => console.error(err));
 }
  $(document).ready(function(){
    $.getScript('https://cdn.botframework.com/botframework-webchat/latest/webchat.js');
    $.getScript('https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js');
    console.log('In directline jquery ')
    // your-script.js is now loaded and you can use any function from it.

});




document.getElementById('botToggle').addEventListener('click', function () {
  
  if (document.getElementById('chat-window').classList.contains('seen')) {
    document.getElementById('chat-window').classList.remove('seen');
    document.getElementById('webchat').classList.remove('seen');
    document.getElementById('botToggle').classList.remove('seen');
    document.getElementsByClassName('bot-tip')[0].innerHTML = 'Talk to CROMA';
    document.querySelector('#botToggle i').innerHTML = 'person';
    
  } else {
    
    document.getElementById('chat-window').classList.add('seen');
    document.getElementById('webchat').classList.add('seen');
    document.getElementById('botToggle').classList.add('seen');
    document.getElementsByClassName('bot-tip')[0].innerHTML = 'Hide CROMA';
    document.querySelector('#botToggle i').innerHTML = 'keyboard_arrow_right';
   
  }
  // var a = document.querySelector('[data-id="webchat-sendbox-input"]');
  // console.log(a);
});
document.getElementById('home_btn').addEventListener('click', function () {
  //document.getElementById('webchat').innerHTML="";
  //document.getElementsByClassName('css-gtdio3.css-mfy564').remove();
  console.log('in home')
  direct_line();
 // document.getElementById('chat-window').classList.add('seen');
 
 document.getElementById('webchat').classList.add('seen');
});

document.getElementById('close_btn').addEventListener('click', function () {
  if (confirm('Are you sure you want to clear everything and close?')) {
    direct_line();
    document.getElementById('chat-window').classList.remove('seen');
    document.getElementById('webchat').classList.remove('seen');
    document.getElementById('botToggle').classList.remove('seen');
    document.getElementsByClassName('bot-tip')[0].innerHTML = 'Talk to CROMA';
    document.querySelector('#botToggle i').innerHTML = 'person';
  }
});

function minimizeWindowFn() {
    document.getElementById('chat-window').style.display="none";
    // document.getElementById('Min-Window-small').style.display="block";

}


function closeWindowFn() {

    document.getElementById('chat-window').style.display="none";
    // document.getElementById('Min-Window-small').style.display="none"; 
      // console.log("inside close window");
}

function maximizeWindowFn() {
    document.getElementById('chat-window').style.display="block";
    // document.getElementById('Min-Window-small').style.display="none";
}


// $(document).ready(function(){
// $("body").on('DOMSubtreeModified', "#chatlogs", function() {
//   //alert('changed');
//   var terminalResultsDiv = document.getElementById('chatlogs');

//   terminalResultsDiv.scrollTop = terminalResultsDiv.scrollHeight;
//   console.log("scrolled");
// }); 
// });

$(document).ready(function(){
$("body").on('DOMSubtreeModified', "[role=log]", function() {
  //alert('changed');
  var terminalResultsDiv = $("[role=log]");
  
  terminalResultsDiv.scrollTop = terminalResultsDiv.scrollHeight;
  // console.log("scrolled");


}); 
$.getScript('https://cdn.botframework.com/botframework-webchat/latest/webchat.js');
console.log('in seperate func')
    // your-script.js is now loaded and you can use any function from it.

});

$(document).ready(function(){
  
  var term = $('input').attr('data-id');
  console.log()
 

});
function setUserResponse(val) {
        var UserResponse = '<p class="userEnteredText">' + val + '</p><div class="clearfix"></div>';
        $(UserResponse).appendTo('#result_div');
        $("#chat-input").val('');
        scrollToBottomOfResults();
        showSpinner();
         $('.spinner').fadeIn(5000,function(){
            $('.spinner').fadeOut(6000);
            
        });
       /*  var Response = '<p class="botResult">' + "Network Error" + '</p><div class="clearfix"></div>';
                $(Response).appendTo('#result_div');*/

        $('.suggestion').remove();
    }
    
 


function dateFunction() {
    document.getElementById("date").value= "Today, "+time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
    document.getElementById("date").innerHTML=document.getElementById("date").value;
 }