
 // ******************  UI CODE STARTS ********************
glob=0;
var time = new Date();
function direct_line(){
  console.log('in direct line')
  
  
  
  window.WebChat.renderWebChat({
    directLine: window.WebChat.createDirectLine({ secret: '-DSZBedERzg.CRYNiXWFgdJGkMRpCDTq0zQdIPBKJsXBdYrlmJFsANU',
     //webSpeechPonyfillFactory: window.WebChat.createBrowserWebSpeechPonyfillFactory()
     }),
     
    styleOptions: {
      botAvatarImage: 'icons/bot-icon.svg',
      // botAvatarInitials: 'BF',
      userAvatarImage: 'icons/userAvatar.jpg',
      userAvatarInitials: 'WC'
    }
    // Passing avatar initials when rendering Web Chat

  }, document.getElementById('webchat'));
  document.querySelector('#webchat > *').focus();

  $(document).ready(function(){
    $.getScript('https://cdn.botframework.com/botframework-webchat/latest/webchat.js');
    $.getScript('https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js');
    console.log('In directline jquery ')
    // your-script.js is now loaded and you can use any function from it.

});


}

document.getElementById('botToggle').addEventListener('click', function () {
  
  if (document.getElementById('chat-window').classList.contains('seen')) {
    document.getElementById('chat-window').classList.remove('seen');
    document.getElementById('webchat').classList.remove('seen');
    document.getElementById('botToggle').classList.remove('seen');
    document.getElementsByClassName('bot-tip')[0].innerHTML = 'Talk to Baymax';
    document.querySelector('#botToggle i').innerHTML = 'person';
    
  } else {
    
    document.getElementById('chat-window').classList.add('seen');
    document.getElementById('webchat').classList.add('seen');
    document.getElementById('botToggle').classList.add('seen');
    document.getElementsByClassName('bot-tip')[0].innerHTML = 'Hide Baymax';
    document.querySelector('#botToggle i').innerHTML = 'keyboard_arrow_right';
   
  }
  // var a = document.querySelector('[data-id="webchat-sendbox-input"]');
  // console.log(a);
});

document.getElementById('home_btn').addEventListener('click', function () {
  //document.getElementById('webchat').innerHTML="";
  //document.getElementsByClassName('css-gtdio3.css-mfy564').remove();
  console.log('in home')
  direct_line();
 // document.getElementById('chat-window').classList.add('seen');
 
 document.getElementById('webchat').classList.add('seen');
});


document.getElementById('close_btn').addEventListener('click', function () {
  if (confirm('Are you sure you want to clear everything and close?')) {
    direct_line();
    document.getElementById('chat-window').classList.remove('seen');
    document.getElementById('webchat').classList.remove('seen');
    document.getElementById('botToggle').classList.remove('seen');
    document.getElementsByClassName('bot-tip')[0].innerHTML = 'Talk to Maxis';
    document.querySelector('#botToggle i').innerHTML = 'person';
  }
});

function minimizeWindowFn() {
    document.getElementById('chat-window').style.display="none";
    // document.getElementById('Min-Window-small').style.display="block";

}


function closeWindowFn() {

    document.getElementById('chat-window').style.display="none";
    // document.getElementById('Min-Window-small').style.display="none"; 
      // console.log("inside close window");
}

function maximizeWindowFn() {
    document.getElementById('chat-window').style.display="block";
    // document.getElementById('Min-Window-small').style.display="none";
}


// $(document).ready(function(){
// $("body").on('DOMSubtreeModified', "#chatlogs", function() {
//   //alert('changed');
//   var terminalResultsDiv = document.getElementById('chatlogs');

//   terminalResultsDiv.scrollTop = terminalResultsDiv.scrollHeight;
//   console.log("scrolled");
// }); 
// });

$(document).ready(function(){
$("body").on('DOMSubtreeModified', "[role=log]", function() {
  //alert('changed');
  var terminalResultsDiv = $("[role=log]");
  
  terminalResultsDiv.scrollTop = terminalResultsDiv.scrollHeight;
  // console.log("scrolled");


}); 
$.getScript('https://cdn.botframework.com/botframework-webchat/latest/webchat.js');
console.log('in seperate func')
    // your-script.js is now loaded and you can use any function from it.

});

$(document).ready(function(){
  
  var term = $('input').attr('data-id');
  console.log()
 

});
function setUserResponse(val) {
        var UserResponse = '<p class="userEnteredText">' + val + '</p><div class="clearfix"></div>';
        $(UserResponse).appendTo('#result_div');
        $("#chat-input").val('');
        scrollToBottomOfResults();
        showSpinner();
         $('.spinner').fadeIn(5000,function(){
            $('.spinner').fadeOut(6000);
            
        }); 
       /*  var Response = '<p class="botResult">' + "Network Error" + '</p><div class="clearfix"></div>';
                $(Response).appendTo('#result_div');*/

        $('.suggestion').remove();
    }
    
 


function dateFunction() {
    document.getElementById("date").value= "Today, "+time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
    document.getElementById("date").innerHTML=document.getElementById("date").value;
 }